const DIM = 10;
let livello = 0;
let timerId;

window.addEventListener("load", function () {
    CaricaMatrice();

    livello = 0;

    // Ogni 500 ms verrà richiamata AggiornaCornice
    timerId = setInterval(AggiornaCornice, 500);

    document.getElementById("btn-stop").addEventListener("click", BtnStopClick);
});

function BtnStopClick() {
    // Cancella la temporizzazione
    clearInterval(timerId);
}

function CaricaMatrice() {
    const wrapper = document.getElementById("wrapper");

    for (let i = 0; i < DIM; i++) {
        for (let j = 0; j < DIM; j++) {
            const cella = document.createElement("div");

            cella.classList.add("cella");
            cella.id = `div-${i}-${j}`;

            wrapper.appendChild(cella);
        }
    }
}

function AggiornaCornice() {
    ResetCelle();

    // For generazione cornice alta e bassa
    for (let j = livello; j < DIM - livello; j++) {
        const cellaAlta = document.getElementById(`div-${livello}-${j}`);
        cellaAlta.style.backgroundColor = "#FF0000";

        const cellaBassa = document.getElementById(`div-${DIM - 1 - livello}-${j}`);
        cellaBassa.style.backgroundColor = "#FF0000";
    }

    // For generazione cornice sinistra e destra
    for (let i = livello + 1; i < DIM - 1 - livello; i++) {
        const cellaSx = document.getElementById(`div-${i}-${livello}`);
        cellaSx.style.backgroundColor = "#FF0000";

        const cellaDx = document.getElementById(`div-${i}-${DIM - 1 - livello}`);
        cellaDx.style.backgroundColor = "#FF0000";
    }

    livello++;

    // Gestione reset livello
    if (livello == 5) {
        livello = 0;
    }
}

function ResetCelle() {
    const celle = document.querySelectorAll("#wrapper > div");

    for (const cella of celle) {
        cella.style.backgroundColor = "#CCC";
    }
}

function GeneraNumero(min, max) {
    let rnd = Math.floor((max - min) * Math.random()) + min;
    return rnd;
}