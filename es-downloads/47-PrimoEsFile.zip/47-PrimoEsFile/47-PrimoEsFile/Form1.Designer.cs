﻿namespace _47_PrimoEsFile
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLeggi = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnCopia = new System.Windows.Forms.Button();
            this.btnContaLineeParole = new System.Windows.Forms.Button();
            this.btnSostituireNuovoFile = new System.Windows.Forms.Button();
            this.btnSostituireStessoFile = new System.Windows.Forms.Button();
            this.rtbUno = new System.Windows.Forms.RichTextBox();
            this.rtbDue = new System.Windows.Forms.RichTextBox();
            this.btnContaOccorrenze = new System.Windows.Forms.Button();
            this.btnLunghezzaMediaParole = new System.Windows.Forms.Button();
            this.cmbParole = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnLeggi
            // 
            this.btnLeggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeggi.Location = new System.Drawing.Point(13, 13);
            this.btnLeggi.Name = "btnLeggi";
            this.btnLeggi.Size = new System.Drawing.Size(180, 63);
            this.btnLeggi.TabIndex = 0;
            this.btnLeggi.Text = "LEGGI DAL FILE ";
            this.btnLeggi.UseVisualStyleBackColor = true;
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifica.Location = new System.Drawing.Point(13, 76);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(180, 63);
            this.btnModifica.TabIndex = 1;
            this.btnModifica.Text = "MODIFICA FILE ";
            this.btnModifica.UseVisualStyleBackColor = true;
            // 
            // btnCopia
            // 
            this.btnCopia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopia.Location = new System.Drawing.Point(13, 139);
            this.btnCopia.Name = "btnCopia";
            this.btnCopia.Size = new System.Drawing.Size(180, 63);
            this.btnCopia.TabIndex = 2;
            this.btnCopia.Text = "COPIA FILE ";
            this.btnCopia.UseVisualStyleBackColor = true;
            // 
            // btnContaLineeParole
            // 
            this.btnContaLineeParole.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLineeParole.Location = new System.Drawing.Point(13, 202);
            this.btnContaLineeParole.Name = "btnContaLineeParole";
            this.btnContaLineeParole.Size = new System.Drawing.Size(180, 63);
            this.btnContaLineeParole.TabIndex = 3;
            this.btnContaLineeParole.Text = "CONTA N° LINEE E PAROLE";
            this.btnContaLineeParole.UseVisualStyleBackColor = true;
            // 
            // btnSostituireNuovoFile
            // 
            this.btnSostituireNuovoFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSostituireNuovoFile.Location = new System.Drawing.Point(13, 265);
            this.btnSostituireNuovoFile.Name = "btnSostituireNuovoFile";
            this.btnSostituireNuovoFile.Size = new System.Drawing.Size(180, 63);
            this.btnSostituireNuovoFile.TabIndex = 4;
            this.btnSostituireNuovoFile.Text = "SOSTITUIRE UNA PAROLA IN NUOVO FILE";
            this.btnSostituireNuovoFile.UseVisualStyleBackColor = true;
            // 
            // btnSostituireStessoFile
            // 
            this.btnSostituireStessoFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSostituireStessoFile.Location = new System.Drawing.Point(199, 166);
            this.btnSostituireStessoFile.Name = "btnSostituireStessoFile";
            this.btnSostituireStessoFile.Size = new System.Drawing.Size(260, 50);
            this.btnSostituireStessoFile.TabIndex = 5;
            this.btnSostituireStessoFile.Text = "SOSTITUIRE NELLO STESSO FILE UNA PAROLA";
            this.btnSostituireStessoFile.UseVisualStyleBackColor = true;
            // 
            // rtbUno
            // 
            this.rtbUno.Location = new System.Drawing.Point(199, 12);
            this.rtbUno.Name = "rtbUno";
            this.rtbUno.Size = new System.Drawing.Size(260, 148);
            this.rtbUno.TabIndex = 6;
            this.rtbUno.Text = "";
            // 
            // rtbDue
            // 
            this.rtbDue.Location = new System.Drawing.Point(465, 12);
            this.rtbDue.Name = "rtbDue";
            this.rtbDue.Size = new System.Drawing.Size(260, 148);
            this.rtbDue.TabIndex = 7;
            this.rtbDue.Text = "";
            // 
            // btnContaOccorrenze
            // 
            this.btnContaOccorrenze.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaOccorrenze.Location = new System.Drawing.Point(199, 222);
            this.btnContaOccorrenze.Name = "btnContaOccorrenze";
            this.btnContaOccorrenze.Size = new System.Drawing.Size(260, 50);
            this.btnContaOccorrenze.TabIndex = 8;
            this.btnContaOccorrenze.Text = "CONTARE LE OCCORRENZE DELLE PAROLE NEL TESTO";
            this.btnContaOccorrenze.UseVisualStyleBackColor = true;
            // 
            // btnLunghezzaMediaParole
            // 
            this.btnLunghezzaMediaParole.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLunghezzaMediaParole.Location = new System.Drawing.Point(465, 166);
            this.btnLunghezzaMediaParole.Name = "btnLunghezzaMediaParole";
            this.btnLunghezzaMediaParole.Size = new System.Drawing.Size(260, 50);
            this.btnLunghezzaMediaParole.TabIndex = 9;
            this.btnLunghezzaMediaParole.Text = "CALCOLARE LA LUNGHEZZA MEDIA DELLE PAROLE";
            this.btnLunghezzaMediaParole.UseVisualStyleBackColor = true;
            // 
            // cmbParole
            // 
            this.cmbParole.FormattingEnabled = true;
            this.cmbParole.Location = new System.Drawing.Point(479, 238);
            this.cmbParole.Name = "cmbParole";
            this.cmbParole.Size = new System.Drawing.Size(188, 21);
            this.cmbParole.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 341);
            this.Controls.Add(this.cmbParole);
            this.Controls.Add(this.btnLunghezzaMediaParole);
            this.Controls.Add(this.btnContaOccorrenze);
            this.Controls.Add(this.rtbDue);
            this.Controls.Add(this.rtbUno);
            this.Controls.Add(this.btnSostituireStessoFile);
            this.Controls.Add(this.btnSostituireNuovoFile);
            this.Controls.Add(this.btnContaLineeParole);
            this.Controls.Add(this.btnCopia);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnLeggi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLeggi;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnCopia;
        private System.Windows.Forms.Button btnContaLineeParole;
        private System.Windows.Forms.Button btnSostituireNuovoFile;
        private System.Windows.Forms.Button btnSostituireStessoFile;
        private System.Windows.Forms.RichTextBox rtbUno;
        private System.Windows.Forms.RichTextBox rtbDue;
        private System.Windows.Forms.Button btnContaOccorrenze;
        private System.Windows.Forms.Button btnLunghezzaMediaParole;
        private System.Windows.Forms.ComboBox cmbParole;
    }
}

